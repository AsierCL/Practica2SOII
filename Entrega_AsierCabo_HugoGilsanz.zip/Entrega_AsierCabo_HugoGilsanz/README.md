# Práctica 2 - Sincronización de procesos con semáforos

## Ejercicios

### Apartado 1

Los archivos que pertenecen a este apartado son:
- Código prod.c
- Código cons.c
- Informe "*Problema del productor-consumidor con memoria compartida*"

### Apartado 2

Los archivos que pertenecen a este apartado son:
- Código prod_sem.c
- Código cons_sem.c
- Informe "*Uso de semáforos para la resolución de carreras críticas*"

### Apartado 3

Los archivos que pertenecen a este apartado son:
- Código op1.c
- Informe "*Compatibilidad de semáforos e hilos en el problema del productor-consumidor*"

### Apartado 4

Los archivos que pertenecen a este apartado son:
- Código op2.c
- Informe "*Generalización de procesos en el problema del productor-consumidor*"